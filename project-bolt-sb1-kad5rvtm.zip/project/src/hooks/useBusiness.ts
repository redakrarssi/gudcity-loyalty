import { useBusinessContext } from '../contexts/BusinessContext';

export function useBusiness() {
  return useBusinessContext();
}